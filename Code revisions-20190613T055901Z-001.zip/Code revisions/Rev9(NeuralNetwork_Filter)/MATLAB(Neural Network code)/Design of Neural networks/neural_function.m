function [y] = neural_function(X, synapse0, synapse1 )
%Sees if the neural network is good enough when sigmoid is approximated as
%a step function

%Synapse 1
neuron = X*synapse0;

%Thresholding 
neuron(neuron < 0) = 0;

%Synapse 2
y = neuron*synapse1;

y(y<0) = 0;
y(y>0) = 1;

disp(y)



end