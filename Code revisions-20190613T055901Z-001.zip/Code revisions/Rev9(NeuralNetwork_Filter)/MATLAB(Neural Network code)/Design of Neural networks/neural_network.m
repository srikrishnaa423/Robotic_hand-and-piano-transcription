function [syn0, syn1] = neural_network(X,y,layer_description,convergence)
%X is a matrix where each row is a training set. 
%y is a matrix with each row a seperate training set



%Initialize the synapse matrices
rng(1);
syn0 = 2*(rand(layer_description(1),layer_description(2))) - 1;
rng(1);
syn1 = 2*(rand(layer_description(2),layer_description(3))) - 1;
l0 = [];
l1 = [];
l2 = [];
l2_error = [];
l2_delta = [];
l1_error = [];
l1_delta = [];



for i = 1:convergence
    %Prediction
    l0 = X;
    l1 = sigmoid(l0*syn0,0);
    l2 = sigmoid(l1*syn1,0);
    
    
    %Backpropogation for error estimation
    %Print error
    l2_error = y - l2;
    if(mod(i,10000) == 0)
        disp(['Error: ' num2str(mean(abs(l2_error)))]);
    end
    l2_delta = l2_error.*sigmoid(l2,1);
    
    l1_error = l2_delta*transpose(syn1);
    l1_delta = l1_error.*sigmoid(l1,1);
    
    
    %Update weights for each step
    syn1 = syn1 + transpose(l1)*l2_delta;
    syn0 = syn0 + transpose(l0)*l1_delta;
    
end


disp('Output after training');
disp(l2);



end