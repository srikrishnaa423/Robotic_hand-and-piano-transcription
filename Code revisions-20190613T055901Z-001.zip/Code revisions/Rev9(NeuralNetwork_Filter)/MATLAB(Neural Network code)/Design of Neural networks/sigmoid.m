function [y] = sigmoid(x,deriv)
%Calculates the sigmoid value of the given function given a input value. 

if(deriv == 0)
    y = 1./(1 + exp(-x));
else
    y = x.*(1-x);
end
end