/* 
 * File:   motor_control_thread.h
 * Author: Lab User
 *
 * Created on October 20, 2016, 6:26 PM
 */

#ifndef MOTOR_CONTROL_THREAD_H
#define	MOTOR_CONTROL_THREAD_H







static PT_THREAD(protothread_motor_control(struct pt *pt))
{
    PT_BEGIN(pt);
      

    while(1)
    {
        for(i=0 ; i<2 ; i++)      //Calculates the averaged value of the signal input
        {
            current_input[i] = ReadADC10(i);
            
            //Moving average filter
            lowpass_filter(i);      //The output values are stored as global variables
            output_TFT_int(30,100,ReadADC10(0));
            
            //Updates the history
            update_history(i);
        }
        
        
        //Neural network
        run_neural_network();       //Finds output from filter_output[] and stores it in global variable finger[]
        
        
        //Move finger servo
        move_finger();
        
        PT_YIELD_TIME_msec(30);
    }
    PT_END(pt);
} // motor control thread


#endif	/* MOTOR_CONTROL_THREAD_H */

