/* 
 * File:   Neural_network.h
 * Author: Krishnaa
 *
 * Created on 3 December, 2016, 10:51 PM
 */

#ifndef NEURAL_NETWORK_H
#define	NEURAL_NETWORK_H

void run_neural_network(void)
{
    //Synapse0 propogation
    for(i=0 ; i<10 ; i++)           //For all neurons
    {
        neuron[i] = multfix16(int2fix16(filter_output[0]),synapse0[0][i])      +      multfix16(int2fix16(filter_output[1]),synapse0[1][i]);     //As only two inputs exist
    }
    
    
    //Synapse1 propogation
    finger_probability[0] = fix16_zero;
    finger_probability[1] = fix16_zero;
    finger_probability[2] = fix16_zero;
    finger_probability[3] = fix16_zero;
    finger_probability[4] = fix16_zero;
    for(i=0 ; i<10 ; i++)       //For all neurons
    {
        if(fix2int16(neuron[i]) < 0)        //Thresholding at each neuron. A simple step function
        {
            neuron[i] = fix16_zero;
        }
        
        finger_probability[0] = finger_probability[0] + multfix16(neuron[i],synapse1[i][0]);
        finger_probability[1] = finger_probability[1] + multfix16(neuron[i],synapse1[i][1]);
        finger_probability[2] = finger_probability[2] + multfix16(neuron[i],synapse1[i][2]);
        finger_probability[3] = finger_probability[3] + multfix16(neuron[i],synapse1[i][3]);
        finger_probability[4] = finger_probability[4] + multfix16(neuron[i],synapse1[i][4]);
    }
    
    //Output thresholding
    for(i=0 ; i<5 ; i++)
    {
        if(finger_probability[i] < fix16_zero)
        {
            finger_probability[i] = fix16_zero;
        }
        else
        {
            finger_probability[i] = fix16_one;
        }
    }
    
}

#endif	/* NEURAL_NETWORK_H */

