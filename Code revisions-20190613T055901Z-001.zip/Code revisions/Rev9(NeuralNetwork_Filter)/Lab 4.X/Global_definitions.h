
#ifndef GLOBAL_VARIABLES_H
#define	GLOBAL_VARIABLES_H


#define	SYS_FREQ 4000000;                 // config.h sets 40 MHz
    // Open the desired DMA channels.
#define dmaChn0     0
#define dmaChn1     1
#define dmaChn2     2



//Fixed point arithmetic

// === the fixed point macros ========================================
typedef signed int fix16 ;
#define multfix16(a,b) ((fix16)(((( signed long long)(a))*(( signed long long)(b)))>>16)) //multiply two fixed 16:16
#define float2fix16(a) ((fix16)((a)*65536.0)) // 2^16
#define fix2float16(a) ((float)(a)/65536.0)
#define fix2int16(a)    ((int)((a)>>16))
#define int2fix16(a)    ((fix16)((a)<<16))
#define divfix16(a,b) ((fix16)((((signed long long)(a)<<16)/(b)))) 
#define sqrtfix16(a) (float2fix16(sqrt(fix2float16(a)))) 
#define absfix16(a) abs(a)
 fix16 fix16_zero =   0;        //0 equivalent
 fix16 fix16_one =   65536;     //1 equivalent

































//Define threads
static struct pt pt_serial, pt_TFT_display, pt_motor_control ;     
int i;
int j;

// string buffer used to output to TFT
char tft_buffer[60];    


//PWM variables & Times
int min_angle = 1350;  // 540 us for 0 degrees
int max_angle = 6250;   // 2500 us for 180 degrees
int pwm_control = 0;    //pwm_control for the motors

int PWM_50Hz = 50000;       //prescalar 16 -> 800,000/16 = 50,000  Thus the timer runs out at 50 Hz. 



//Filter variables
int input_history[15][2] = 
{{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0}
};   //An array of the previous 15 entries. 
int current_input[2] = {0,0}; //Current ADC read from buffer
int filter_output[2] = {0,0}; //Filter_output (Averager)

//Neural network variables
 fix16 neuron[10] = {0,0,0,0,0,0,0,0,0,0}; //Neural Layer output.    
fix16    finger_probability[5] = {0,0,0,0,0}; // Probability that a finger was pressed
fix16    synapse0[2][10] = 
{{0,0,0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0,0,0}};    //Input to neural layer      //Must hardcode values   
fix16 synapse1[10][5]= 
{{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0},
{0,0,0,0,0}};   // Neural layer to output    //Must hardcode values

























int max_int(int x, int y)
{
    if(x >= y)
    {
        return x;
    }
    else
    {
        return y;
    }
}


float max_float(float x, float y)
{
    if(x >= y)
    {
        return x;
    }
    else
    {
        return y;
    }
}



#endif	/* GLOBAL_VARIABLES_H */

