#ifndef GLOBAL_DECLARATIONS_H
#define	GLOBAL_DECLARATIONS_H

////State machine variable declarations
//typedef enum possible_states 
//{
//    released,
//    maybe,
//    keypress,
//    still_keypress
//} possible_states;
//
//
//typedef enum possible_outputs
//{
//    chill,
//    buffer_sound_dtmf,
//    erase,
//    play_whole,
//    play_single
//} possible_outputs;

#endif	/* GLOBAL_DECLARATIONS_H */

