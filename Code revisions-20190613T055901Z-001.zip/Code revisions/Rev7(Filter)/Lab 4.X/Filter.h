/* 
 * File:   Filter.h
 * Author: Lab User
 *
 * Created on December 3, 2016, 2:55 PM
 */

#ifndef FILTER_H
#define	FILTER_H




//== SOS BANDpass filter, 16-bit ===========================
// 8 pole
// coeff[][section] = {section-a2, section-a3}
// scale[section] = scalar for each section
// history[][section] = { last_1_input, last_2_input, last_1_output, last_2_output}
#define MAX_BP_SECTIONS 4
fix16 coeff_sos[2][MAX_BP_SECTIONS], scale_sos[MAX_BP_SECTIONS], history_sos[4][MAX_BP_SECTIONS], output ;
int num_sections  = 4;

fix16 IIR_butter_sos_bp_16(fix16 input, fix16 coeff_sos[][MAX_BP_SECTIONS],
        fix16 scale_sos[MAX_BP_SECTIONS], fix16 history_sos[][MAX_BP_SECTIONS], int num_sections )
{
    fix16 input_scaled, output ;
    int i ;
    for (i=0; i<num_sections; i++) 
    {
        input_scaled = multfix16(input, scale_sos[i]);
        output = input_scaled - history_sos[1][i] -
                multfix16(history_sos[2][i], coeff_sos[0][i]) -
                multfix16(history_sos[3][i], coeff_sos[1][i]) ;
        history_sos[1][i] = history_sos[0][i] ;
        history_sos[0][i] = input_scaled ;
        history_sos[3][i] = history_sos[2][i] ;
        history_sos[2][i] = output ;
        input = output ; // for the next pass thru the loop
    }
    return output ;
}










void setup_filter_coeff(void)
{
    // Butterworth bandpass low_cutoff=0.001498; hi_cutoff=0.037439; poles=8 
num_sections = 4 ; 
coeff_sos[0][0]= float2fix16(-1.90744) ; 
coeff_sos[1][0]= float2fix16(0.92044) ; 
scale_sos[0] = float2fix16(0.05525) ; 
coeff_sos[0][1]= float2fix16(-1.99659) ; 
coeff_sos[1][1]= float2fix16(0.99662) ; 
scale_sos[1] = float2fix16(0.05525) ; 
coeff_sos[0][2]= float2fix16(-1.99082) ; 
coeff_sos[1][2]= float2fix16(0.99084) ; 
scale_sos[2] = float2fix16(0.05370) ; 
coeff_sos[0][3]= float2fix16(-1.80803) ; 
coeff_sos[1][3]= float2fix16(0.81893) ; 
scale_sos[3] = float2fix16(0.05370) ; 
}

#endif	/* FILTER_H */

