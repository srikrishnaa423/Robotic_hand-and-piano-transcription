/* 
 * File:   motor_control_thread.h
 * Author: Lab User
 *
 * Created on October 20, 2016, 6:26 PM
 */

#ifndef MOTOR_CONTROL_THREAD_H
#define	MOTOR_CONTROL_THREAD_H

void move_direction(int direction)
{  
        SetDCOC1PWM(direction);
}


static PT_THREAD(protothread_motor_control(struct pt *pt))
{
    PT_BEGIN(pt);
    
    while(1)
    {
        //Control motor
        move_direction(middle);         //Moves the motor to a particular direction
        
        PT_YIELD_TIME_msec(1);
    }
    PT_END(pt);
} // motor control thread

#endif	/* MOTOR_CONTROL_THREAD_H */

