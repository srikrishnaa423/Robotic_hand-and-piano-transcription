/* 
 * File:   TFT_display_thread.h
 * Author: Lab User
 *
 * Created on October 20, 2016, 6:24 PM
 */

#ifndef TFT_DISPLAY_THREAD_H
#define	TFT_DISPLAY_THREAD_H




static PT_THREAD(protothread_TFT_display(struct pt *pt))
{
    PT_BEGIN(pt);
    
    while(1)
    {
        output_TFT_int(30,100,CVRCON);
        PT_YIELD_TIME_msec(10); 
    }    
    
    PT_END(pt);
} // TFT display thread

#endif	/* TFT_DISPLAY_THREAD_H */

