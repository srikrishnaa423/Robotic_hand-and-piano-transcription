/* 
 * File:   ISR_routines.h
 * Author: Lab User
 *
 * Created on October 21, 2016, 3:45 PM
 */

#ifndef ISR_ROUTINES_H
#define	ISR_ROUTINES_H

static unsigned int sample_max = 10;
unsigned int sample;
char sample_string[10];
unsigned int sample_counter = 0;
int j = 0;



volatile unsigned int channel0, DAC_value;
//== Timer 2 interrupt handler ===================================
// ASM output is 47 instructions for the ISR
void __ISR(_TIMER_3_VECTOR, ipl2) Timer3Handler(void)
{
    // clear the interrupt flag
    mT3ClearIntFlag();
    // Read the ADC // read the first buffer position
    channel0 = ReadADC10(0);   // read the result of channel 4 conversion from the idle buffer
    //Does the filter
    output = IIR_butter_sos_bp_16(channel0<<4, coeff_sos, scale_sos, history_sos, num_sections );    // shfit the 10-bit ADC value to the left 4 bits to scale to 2.14 fixed format
    // DAC output
    // DAC_value = (output>>6) ; //14-bit shift 6-bits to 8 bit
    DAC_value = (output>>6) + 128 ; //14-bit shift 6-bits to 8 bit FOR BANDPASS
//    mPORTBWrite ((DAC_value & 0x03f) | ((DAC_value & 0xc0)<<8)) ;//| ((DAC_value & 0xf0)<<4)   ;
    
    
    mPORTBClearBits(BIT_9);  // CS low to start transaction  
    while (TxBufFullSPI2());  // test for ready
    WriteSPI2(DAC_channelA | DAC_value); // write to spi2
    while (SPI2STATbits.SPIBUSY);    // test for done// wait for end of transaction
    mPORTBSetBits(BIT_9);  // CS high //End transaction
}

































//// === ISR ============================================
// volatile short current_capture = 0, previous_capture = 0;
// volatile short  capture_period = 0;
//// == Capture 1 ISR ====================================================
//void __ISR(_ADC_VECTOR   , ipl3) ADCHandler(void)
//{
//    // clear the interrupt flag
//    mAD1ClearIntFlag();
//    output_TFT_string(30,100,"ISR!");
//    // read the ADC
//    // read the first buffer position
//    sample = ReadADC10(0);   // read the result of channel 4 conversion from the idle buffer
//
//    //Output to serial at each ARC IRQ
//    itoa(sample_string, sample, 10);  
//    for(j = 0; sample_string[j] != '\0' ; j++)               //Send it over //Might not be right
//    {
//        while(UARTTransmitterIsReady(UART2) == 0);
//        UARTSendDataByte(UART2, sample_string[j]);
//    }        
//    while(UARTTransmitterIsReady(UART2) == 0);       //New line
//    UARTSendDataByte(UART2, '\n');
//    sample_counter++;
//                
//    //Check for max_samples            
//    if(sample_counter == sample_max)
//    {
//        sample_counter = 0;
//        while(UARTTransmitterIsReady(UART2) == 0);       //End
//        UARTSendDataByte(UART2, 'Z');
//        while(UARTTransmitterIsReady(UART2) == 0);       //New line
//        UARTSendDataByte(UART2, '\n');
//        ConfigIntADC10( ADC_INT_OFF ); 
//    }
//}

#endif	/* ISR_ROUTINES_H */

