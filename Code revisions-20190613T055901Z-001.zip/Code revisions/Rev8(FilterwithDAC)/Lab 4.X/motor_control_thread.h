/* 
 * File:   motor_control_thread.h
 * Author: Lab User
 *
 * Created on October 20, 2016, 6:26 PM
 */

#ifndef MOTOR_CONTROL_THREAD_H
#define	MOTOR_CONTROL_THREAD_H



void control_motor(int oc, int angle)
{  
    //Calculating the control
    pwm_control = ((int)(  ((float)angle)  /180.0   )*   ((float)(max_angle - min_angle) ) )      + min_angle    ;
    
    //Clamping the control
    if(pwm_control < min_angle)
    {
        pwm_control = min_angle;
    }
    else if(pwm_control > max_angle)
    {
        pwm_control = max_angle;
    }
    
    //Sending the PWM signal
    switch(oc)
    {
        case 1:
            SetDCOC1PWM(pwm_control);
            break;
        case 2:
            SetDCOC2PWM(pwm_control);
            break;
        case 3:
            SetDCOC3PWM(pwm_control);
            break;
        case 4:
            SetDCOC4PWM(pwm_control);
            break;
        case 5:
            SetDCOC5PWM(pwm_control);
            break;
    }
}






int difference  = 0;
int angle = 0;

static PT_THREAD(protothread_motor_control(struct pt *pt))
{
    PT_BEGIN(pt);
      

    while(1)
    {
        for(i=0; i<5 ; i++)
        {
            //Read finger input
            current_finger_input[i] = ReadADC10(i);
            
            
            
            //Implementing the filter
            difference = current_finger_input[i] - previous_finger_input[i];    //Finds the derivate of the signal 
            //Derivative thresholding
            if(    (difference > (threshold_input[i]))    ||     (difference < (-1*(threshold_input[i])))     )   //Thresholds the input derivative and integrates the values above the threshold
            {
                changes[i] = changes[i] + 1;
            }
            else 
            {
                changes[i] = changes[i] - max_int(((changes[i])>>3),1);    //Does a exponential decay 
                if(changes[i] < 0)                                         //prevents non-negative values
                {
                    changes[i] = 0;
                }
            }
            //Integral thresholding
            if(changes[i] > threshold_output[i])            //Finds the output angle to turn to based on the integral threshold
            {
                angle = 180;
            }
            else 
            {
                angle = 0;
            }
            
            
            
            
            
            
            //Controls the motor with PWM
            control_motor(i,angle);
            
            
            
            
            //Update the previous value
            previous_finger_input[i] = current_finger_input[i];   //Update the previous finger value
        }
        
        PT_YIELD_TIME_msec(10);
    }
    PT_END(pt);
} // motor control thread


#endif	/* MOTOR_CONTROL_THREAD_H */

