/* 
 * File:   Servo_functions.h
 * Author: Krishnaa
 *
 * Created on 3 December, 2016, 11:12 PM
 */

#ifndef SERVO_FUNCTIONS_H
#define	SERVO_FUNCTIONS_H


int difference  = 0;
int angle = 0;

void control_motor(int oc, int angle)
{  
    //Calculating the control
    //pwm_control = ((int)(  ((float)angle)  /180.0   )*   ((float)(max_angle - min_angle) ) )      + min_angle    ;
    if(angle == 180)
    {
        pwm_control = max_angle;
    }
    else if(angle == 0)
    {
        pwm_control = min_angle;
    }
    
    //Clamping the control
//    if(pwm_control < min_angle)
//    {
//        pwm_control = min_angle;
//    }
//    else if(pwm_control > max_angle)
//    {
//        pwm_control = max_angle;
//    }
    
    
    
    //Sending the PWM signal
    switch(oc)
    {
        case 1:
            SetDCOC1PWM(pwm_control);
            break;
        case 2:
            SetDCOC2PWM(pwm_control);
            break;
        case 3:
            SetDCOC3PWM(pwm_control);
            break;
        case 4:
            SetDCOC4PWM(pwm_control);
            break;
        case 5:
            SetDCOC5PWM(pwm_control);
            break;
    }
}


void move_finger(void)
{
    
    //test code for servos
    
    //control_motor(1,0);
    
    
    //Outputting TFT values
    output_TFT_int(30,10,fix2int16(finger_probability[0]));
    output_TFT_int(30,30,fix2int16(finger_probability[1]));
    output_TFT_int(30,70,fix2int16(finger_probability[2]));
    output_TFT_int(30,100,fix2int16(finger_probability[3]));
    output_TFT_int(30,150,fix2int16(finger_probability[4]));
    
    
//    for(i=0 ; i<5 ; i++)
//    {
//        if(fix2int16(finger_probability[i]) == 1)
//        {
//            control_motor(i+1,180);
//        }
//        else
//        {
//            control_motor(i+1,0);
//        }
//    }
}

#endif	/* SERVO_FUNCTIONS_H */

