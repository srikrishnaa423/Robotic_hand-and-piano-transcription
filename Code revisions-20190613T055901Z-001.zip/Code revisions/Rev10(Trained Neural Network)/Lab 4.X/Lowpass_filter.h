/* 
 * File:   Lowpass_filter.h
 * Author: Krishnaa
 *
 * Created on 3 December, 2016, 11:13 PM
 */

#ifndef LOWPASS_FILTER_H
#define	LOWPASS_FILTER_H


//Filter variables
const int averager_length = 31;
fix16 current_input[2] = {0,0}; //Current ADC read from buffer
fix16 filter_output[2] = {0,0}; //Filter_output (Averager)
static fix16 b[3] = {14249, 28497, 14249};       //Butterworth 2nd order filter constants
static fix16 a[2] = {20975, -12435};            //Current cutoff frequency 0.3133 * 13
fix16 last1_input[2] = {0, 0};
fix16 last2_input[2] = {0, 0};
fix16 last1_output[2] = {0, 0};
fix16 last2_output[2] = {0, 0};


fix16 input_history[31][2] = 
{{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0},
{0,0}
};   //An array of the previous 15 entries. 


//
//
//void lowpass_filter(int electrode)         //Does the moving averager which is a low pass filter. Electrode is 0 or 1
//{
//    filter_output[electrode] = multfix16(current_input[electrode],b[0]) + multfix16(last1_input[electrode],b[1]) + multfix16(last2_input[electrode],b[2])
//            + multfix16(last1_output[electrode],a[0]) + multfix16(last2_output[electrode],a[1]);
//}
//
//
//
//
//
//void update_history(int electrode)
//{
//    //Update inputs
//    last2_input[electrode] = last1_input[electrode];
//    last1_input[electrode] = current_input[electrode];
//    
//    //Update outputs
//    last2_output[electrode] = last1_output[electrode];
//    last1_input[electrode]  = filter_output[electrode];
//}



void lowpass_filter(int electrode)         //Does the moving averager which is a low pass filter. Electrode is 0 or 1
{
    filter_output[electrode] = current_input[electrode];
    
    
    for(j = 0; j < averager_length ; j++)
    {
        filter_output[electrode] = filter_output[electrode] + input_history[j][electrode];
    }
    
    filter_output[electrode] = divfix16(filter_output[electrode],int2fix16(averager_length));    //To divide by 16. 
}





void update_history(int electrode)
{
    
    for(j=(averager_length-1) ; j>0 ; j--)
    {
        input_history[j][electrode] = input_history[j-1][electrode];
    }
    
    input_history[0][electrode] = current_input[electrode];
}

#endif	/* LOWPASS_FILTER_H */

