/* 
 * File:   Neural_network.h
 * Author: Krishnaa
 *
 * Created on 3 December, 2016, 10:51 PM
 */

#ifndef NEURAL_NETWORK_H
#define	NEURAL_NETWORK_H


//Neural network variables

fix16 normalization_value = int2fix16(42);
 fix16 neuron[10] = {0,0,0,0,0,0,0,0,0,0}; //Neural Layer output.    
fix16    finger_probability[5] = {0,0,0,0,0}; // Probability that a finger was pressed
//Synapse matrices 
fix16 synapse0[2][10]= 
{{          346040,         -408346,          949163,           92310,          334081,          339517,          480339,          438202,         2828119,         -480171}, 
{          179172,          -52956,        -3487014,         -209529,          274221,          241274,         -162849,         -158330,        -2740627,           15773}}; 
 
fix16 synapse1[10][5]= 
{{         -386389,         -168394,          259095,         -479094,        -1385913}, 
{         1043059,         -805332,         -163879,          830169,          626500}, 
{        -2856934,         -262137,         -306790,         -742251,          500232}, 
{          286059,           46478,         -567638,          658074,         -223834}, 
{         -529120,         -223157,          325725,         -279842,        -1562295}, 
{         -621411,          199386,          317593,         -290484,        -1669397}, 
{         -646101,          540006,         -841737,          139972,        -1063155}, 
{         -600071,          346723,         -771479,          232794,        -1212430}, 
{         2382272,        -1600717,         -478229,        -1859644,         4608558}, 
{          977549,         -972652,         -150510,          798663,          426663}}; 









void run_neural_network(void)
{
    //Synapse0 propogation
    for(i=0 ; i<10 ; i++)           //For all neurons
    {
        neuron[i] = multfix16(divfix16(int2fix16(filter_output[0]), normalization_value),synapse0[0][i])      +      multfix16(divfix16(int2fix16(filter_output[1]), normalization_value),synapse0[1][i]);     //As only two inputs exist
    }
    
    
    //Synapse1 propogation
    finger_probability[0] = fix16_zero;
    finger_probability[1] = fix16_zero;
    finger_probability[2] = fix16_zero;
    finger_probability[3] = fix16_zero;
    finger_probability[4] = fix16_zero;
    for(i=0 ; i<10 ; i++)       //For all neurons
    {
        if(fix2int16(neuron[i]) < 0)        //Thresholding at each neuron. A simple step function
        {
            neuron[i] = fix16_zero;
        }
        else
        {
            neuron[i] = fix16_one;
        }
        
        finger_probability[0] = finger_probability[0] + multfix16(neuron[i],synapse1[i][0]);
        finger_probability[1] = finger_probability[1] + multfix16(neuron[i],synapse1[i][1]);
        finger_probability[2] = finger_probability[2] + multfix16(neuron[i],synapse1[i][2]);
        finger_probability[3] = finger_probability[3] + multfix16(neuron[i],synapse1[i][3]);
        finger_probability[4] = finger_probability[4] + multfix16(neuron[i],synapse1[i][4]);
    }
    
    //Output thresholding
    for(i=0 ; i<5 ; i++)
    {
        if(finger_probability[i] < fix16_zero)
        {
            finger_probability[i] = fix16_zero;
        }
        else
        {
            finger_probability[i] = fix16_one;
        }
    }
    
}

#endif	/* NEURAL_NETWORK_H */

