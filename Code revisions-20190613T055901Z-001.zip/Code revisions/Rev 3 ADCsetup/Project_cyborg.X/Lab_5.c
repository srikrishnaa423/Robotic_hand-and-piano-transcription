/* 
 * File:   Lab_5.c
 * Author: Lab User
 *
 * Created on November 11, 2016, 1:17 PM
 */






//Configuration libs (Include only once!!)                    
#include "config.h"                  

//TFT libs (Include only once!))
#include "tft_master.h"
#include "tft_gfx.h"

//Protothread libs (Include only once!))
#include "pt_cornell_1_2_1.h"  

//Inbuilt libs 
#include <stdlib.h>
#include <plib.h>
#include <math.h>



//Global declarations (can be included multiple times)
#include "Global_declarations.h"

//Global variables (Include only once!!)
#include "Global_definitions.h"

//Peripheral configurations (Include only once!)
#include "Configurations.h"


//Debugging functions (Include only once! )
#include "our_debugger.h"


//Thread files
#include "motor_control_thread.h"
//#include "Serial_write.h"




// === Main  ======================================================
void main(void) {
  
  setup_config();

  
// init the threads
  PT_INIT(&pt_motor_control);
  //PT_INIT(&pt_serial_read);


  // round-robin scheduler for threads
  while(1)
  {
      PT_SCHEDULE(protothread_motor_control(&pt_motor_control));
      //PT_SCHEDULE(protothread_serial(&pt_serial_read));
  }
  
  } // main

// === end  ======================================================