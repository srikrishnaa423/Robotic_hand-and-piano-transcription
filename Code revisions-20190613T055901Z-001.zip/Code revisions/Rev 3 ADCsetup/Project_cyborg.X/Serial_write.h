/* 
 * File:   Serial_write.h
 * Author: Lab User
 *
 * Created on November 14, 2016, 12:47 PM
 */

#ifndef SERIAL_WRITE_H
#define	SERIAL_WRITE_H

static int i,j;

static struct pt pt_serial_read;
char temp[10];

static PT_THREAD(protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    
    while(1)    //Include while loop?
    {
        PT_SPAWN(pt,&pt_input,PT_GetSerialBuffer(&pt_input));   //Stores the value in PT_term_buffer[64]
        
        
        if(PT_term_buffer[0] == 'D')
        {
            //Stop the ADC transfer
            DmaChnDisable(DMA_CHANNEL0);
            
            //Output the hand_input data
            for(i = 0; i < sizeof(hand_input); i+5)
            {
                
                //Convert each element to a string
                itoa(hand_input[i],temp,10);  
                
                //Send it over //Might not be right
                for(j = 0; temp[j] != '\0' ; j++)  
                {
                    PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
                    UARTSendDataByte(UART2, temp[j]);
                }
                
                //New line
                PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
                UARTSendDataByte(UART2, '\n');
            }
        }
        
        //Data transfer complete
        PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
        UARTSendDataByte(UART2, 'Z');
        
        
        DmaChnEnable(DMA_CHANNEL0);
    }
    
    PT_END(pt);
} // Serial read thread


#endif	/* SERIAL_WRITE_H */

