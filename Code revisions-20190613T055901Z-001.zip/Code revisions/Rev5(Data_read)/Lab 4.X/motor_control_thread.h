/* 
 * File:   motor_control_thread.h
 * Author: Lab User
 *
 * Created on October 20, 2016, 6:26 PM
 */

#ifndef MOTOR_CONTROL_THREAD_H
#define	MOTOR_CONTROL_THREAD_H

static int choice = 1;
static int temp = 0;


void integral_thresholding()
{
    if(sign(error) == sign(previous_error)){
        if(measured_frequency >= fraction_of_measured*measured_frequency){
            integral = 0;
        
        }
        else{
            integral = max_float(integral, integral_max);
        }
    }
    else{
        integral = 0;
    }
}




void output_thresholding(void)
{
    if(PID_output >=min_rpm)
    {
        if(PID_output > max_rpm)
        {
            PID_output = max_rpm;
        }
    }
    else 
    {
        PID_output = min_rpm;
    }
}


void run_PID()
{
    //Calculate the parameters necessary for the PID
    measured_frequency = ((float)(((float) capture_2_rpm)/((float) capture_period)));
    error = desired_frequency - measured_frequency;
    integral = integral + error;
    derivative = (error - previous_error);
    
    //Do some thresholding and checking here?
    integral_thresholding();
    
    //Calculate the PID output
    PID_output = (Kp*error + Ki*integral + Kd*derivative);
    
    //Output thresholding
    output_thresholding();
    
    //Update the error
    previous_error = error;
    
}



void control_motor()
{  
        pwm_control = (int)(PID_output/((float) 3000.0)  * ((float)40000));
        if(pwm_control > 40000)
        {
          pwm_control = max_int(pwm_control,40000);
        }
        if(pwm_control < 0)
        {
            pwm_control = 0;
        }
        SetDCOC1PWM(pwm_control);
}



void send_rpm_PWM()
{
    temp = max_int(40000,((int)(((float) capture_2_pwm)/((float) capture_period))));
    SetDCOC2PWM(temp);
}

int begin_time, execution_time;
static PT_THREAD(protothread_motor_control(struct pt *pt))
{
    PT_BEGIN(pt);
    
    while(1)
    {
        //begin_time = PT_GET_TIME();
        
        //Run PID
        run_PID();
        
        //Send control to motor
        control_motor();
        
        //Measured RPM sent as PWM to pin 14. (RB5)
        send_rpm_PWM();
        
        execution_time = PT_GET_TIME() - begin_time;
        
        //PT_YIELD_TIME_msec(10);
        PT_YIELD_TIME_msec(10 - execution_time);
    }
    PT_END(pt);
} // motor control thread

#endif	/* MOTOR_CONTROL_THREAD_H */

