
#ifndef GLOBAL_VARIABLES_H
#define	GLOBAL_VARIABLES_H


#define	SYS_FREQ 4000000;                 // config.h sets 40 MHz
    // Open the desired DMA channels.
#define dmaChn0     0
#define dmaChn1     1
#define dmaChn2     2



//Fixed point arithmetic

// === the fixed point macros ========================================
typedef signed int fix16 ;
#define multfix16(a,b) ((fix16)(((( signed long long)(a))*(( signed long long)(b)))>>16)) //multiply two fixed 16:16
#define float2fix16(a) ((fix16)((a)*65536.0)) // 2^16
#define fix2float16(a) ((float)(a)/65536.0)
#define fix2int16(a)    ((int)((a)>>16))
#define int2fix16(a)    ((fix16)((a)<<16))
#define divfix16(a,b) ((fix16)((((signed long long)(a)<<16)/(b)))) 
#define sqrtfix16(a) (float2fix16(sqrt(fix2float16(a)))) 
#define absfix16(a) abs(a)


































//Define threads
static struct pt pt_serial, pt_TFT_display, pt_motor_control ;     
int i;
int j;

// string buffer used to output to TFT
char tft_buffer[60];    


//PWM variables & Timer
int pwm_control = 40000 ;
int PWM_1kHz = 40000 ;
int pwm_rpm = 40000;

//Constants for rpm and PWM
float capture_2_pwm = 142857142.857;
float capture_2_rpm = 10714285.7143;


//Serial input parameters
static float serial_desired_frequency = 0.0, P = 0.0, I = 0.0, D = 0.0; 
static float measured_frequency = 0.0;

//PID parameters
static float desired_frequency = 0.0;
static float Kp = 20.0, Ki = 0.02, Kd = 30.0;
static float error = 0.0, previous_error  = 0.0, integral = 0.0, derivative = 0.0;
static float dt = 10.0;  //Units in msec
static float PID_output = 0.0;
static float integral_max = 5000.0;
static float fraction_of_measured = 0.9;

//PID bound parameters
static float max_rpm = 3000.0;
static float min_rpm = 0.0;



























int max_int(int x, int y)
{
    if(x >= y)
    {
        return x;
    }
    else
    {
        return y;
    }
}


float max_float(float x, float y)
{
    if(x >= y)
    {
        return x;
    }
    else
    {
        return y;
    }
}



#endif	/* GLOBAL_VARIABLES_H */

