/* 
 * File:   Global_declarations.h
 * Author: Lab User
 *
 * Created on November 11, 2016, 1:21 PM
 */

#ifndef GLOBAL_DECLARATIONS_H
#define	GLOBAL_DECLARATIONS_H



#endif	/* GLOBAL_DECLARATIONS_H */

