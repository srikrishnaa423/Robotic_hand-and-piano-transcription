/* 
 * File:   ISR_routines.h
 * Author: Lab User
 *
 * Created on November 17, 2016, 5:08 PM
 */

#ifndef ISR_ROUTINES_H
#define	ISR_ROUTINES_H

unsigned int sample;
char* sample_string[10];
unsigned int sample_counter = 0;
//ADC ISR
void __ISR(_ADC_VECTOR , ipl2) Timer2Handler(void)
{
    // clear the interrupt flag
    mAD1ClearIntFlag()
    // read the ADC
    // read the first buffer position
    sample = ReadADC10(0);   // read the result of channel 4 conversion from the idle buffer

    //Output to serial at each ARC IRQ

                itoa(sample,sample_string,10);  
                
                //Send it over //Might not be right
                for(j = 0; sample_string[j] != '\0' ; j++)  
                {
                    PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
                    UARTSendDataByte(UART2, temp[j]);
                }
                
                //New line
                PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
                UARTSendDataByte(UART2, '\n');
                sample_counter++;
                
                
     if(sample_counter == samples)
     {
         PT_YIELD_UNTIL(pt, UARTTransmitterIsReady(UART2));
         UARTSendDataByte(UART2, 'Z');
         mAD1IntEnable(0);
     }
}

#endif	/* ISR_ROUTINES_H */

