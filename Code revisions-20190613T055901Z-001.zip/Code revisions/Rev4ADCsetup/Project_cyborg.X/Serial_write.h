/* 
 * File:   Serial_write.h
 * Author: Lab User
 *
 * Created on November 14, 2016, 12:47 PM
 */

#ifndef SERIAL_WRITE_H
#define	SERIAL_WRITE_H

static int i,j;

static struct pt pt_serial_read;
char temp[10];

static PT_THREAD(protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    
    while(1)    //Include while loop?
    {
        PT_SPAWN(pt,&pt_input,PT_GetSerialBuffer(&pt_input));   //Stores the value in PT_term_buffer[64]
        
        
        if(PT_term_buffer[0] == 'D')
        {
            mAD1IntEnable(1);
        }
    }
    
    PT_END(pt);
} // Serial read thread


#endif	/* SERIAL_WRITE_H */

