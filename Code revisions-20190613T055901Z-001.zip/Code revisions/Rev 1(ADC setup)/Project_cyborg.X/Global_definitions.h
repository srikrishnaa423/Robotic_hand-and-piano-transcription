/* 
 * File:   Global_definitions.h
 * Author: Lab User
 *
 * Created on November 11, 2016, 1:05 PM
 */

#ifndef GLOBAL_DEFINITIONS_H
#define	GLOBAL_DEFINITIONS_H

#define	SYS_FREQ 40000000;                 // config.h sets 40 MHz




//Define threads
static struct pt pt_motor_control ;     


// string buffer used to output to TFT
char tft_buffer[60]; 


//Servo control variables
static int servo_pwm_period;
static int servo1_control, servo2_control, servo3_control, servo4_control, servo5_control; 

//ADC variables
static float hand_input[2560]; //512*5, as we choose 512 as the buffer size for a single electrode
static short size_handinput = 10240; //2560*4 bytes. 



//PWM variables & Timer
static int PWM_50Hz = 50000 ;             //So that the timer works at 20ms
static int left  = 2500;                    //So that the pulse is 1ms  
static int middle  = 3750;                 //Pulse is 1.5 ms
static int right = 5000;                    //Pulse is 2 ms

#endif	/* GLOBAL_DEFINITIONS_H */

